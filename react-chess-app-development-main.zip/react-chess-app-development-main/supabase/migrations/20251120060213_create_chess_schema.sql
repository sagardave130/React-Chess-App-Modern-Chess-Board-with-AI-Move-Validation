/*
  # Create Chess Application Schema

  1. New Tables
    - `profiles` - User profiles and statistics
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `username` (text, unique)
      - `wins` (integer, default 0)
      - `losses` (integer, default 0)
      - `draws` (integer, default 0)
      - `created_at` (timestamp)

    - `games` - Chess game records
      - `id` (uuid, primary key)
      - `white_player_id` (uuid, foreign key)
      - `black_player_id` (uuid, foreign key)
      - `status` (text: 'active', 'white_win', 'black_win', 'draw')
      - `fen` (text, current board state in FEN notation)
      - `move_count` (integer, default 0)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `game_moves` - Move history
      - `id` (uuid, primary key)
      - `game_id` (uuid, foreign key)
      - `move_number` (integer)
      - `from_square` (text)
      - `to_square` (text)
      - `promotion` (text, nullable)
      - `san` (text, algebraic notation)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Users can only view their own profile and public game data
    - Users can only create and update their own games
    - Move history is publicly readable for active games
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  wins integer DEFAULT 0,
  losses integer DEFAULT 0,
  draws integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  white_player_id uuid NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
  black_player_id uuid NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
  status text DEFAULT 'active' CHECK (status IN ('active', 'white_win', 'black_win', 'draw')),
  fen text DEFAULT 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  move_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT different_players CHECK (white_player_id != black_player_id)
);

ALTER TABLE games ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view games"
  ON games FOR SELECT
  USING (true);

CREATE POLICY "Players can create games"
  ON games FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = white_player_id OR auth.uid() = black_player_id);

CREATE POLICY "Players can update their own games"
  ON games FOR UPDATE
  TO authenticated
  USING (auth.uid() = white_player_id OR auth.uid() = black_player_id)
  WITH CHECK (auth.uid() = white_player_id OR auth.uid() = black_player_id);

CREATE TABLE IF NOT EXISTS game_moves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  move_number integer NOT NULL,
  from_square text NOT NULL,
  to_square text NOT NULL,
  promotion text,
  san text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE game_moves ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view game moves"
  ON game_moves FOR SELECT
  USING (true);

CREATE POLICY "Players can insert moves for their games"
  ON game_moves FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM games
      WHERE games.id = game_moves.game_id
      AND (games.white_player_id = auth.uid() OR games.black_player_id = auth.uid())
      AND games.status = 'active'
    )
  );

CREATE INDEX IF NOT EXISTS idx_profiles_user_id ON profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_games_white_player ON games(white_player_id);
CREATE INDEX IF NOT EXISTS idx_games_black_player ON games(black_player_id);
CREATE INDEX IF NOT EXISTS idx_games_status ON games(status);
CREATE INDEX IF NOT EXISTS idx_game_moves_game_id ON game_moves(game_id);
