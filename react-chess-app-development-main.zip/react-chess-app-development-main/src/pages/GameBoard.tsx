import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { ChessBoard } from '../components/ChessBoard';
import { Game, GameMove, Profile } from '../types';
import { ChevronLeft, Copy, Check } from 'lucide-react';

export function GameBoard() {
  const { gameId } = useParams<{ gameId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [moves, setMoves] = useState<GameMove[]>([]);
  const [whitePlayer, setWhitePlayer] = useState<Profile | null>(null);
  const [blackPlayer, setBlackPlayer] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!gameId) return;
    fetchGame();
  }, [gameId]);

  const fetchGame = async () => {
    try {
      const { data: gameData, error: gameError } = await supabase
        .from('games')
        .select('*')
        .eq('id', gameId)
        .maybeSingle();

      if (gameError) throw gameError;
      if (!gameData) {
        setError('Game not found');
        setLoading(false);
        return;
      }

      setGame(gameData);

      const { data: movesData, error: movesError } = await supabase
        .from('game_moves')
        .select('*')
        .eq('game_id', gameId)
        .order('move_number');

      if (movesError) throw movesError;
      setMoves(movesData || []);

      const { data: whiteData } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', gameData.white_player_id)
        .maybeSingle();

      const { data: blackData } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', gameData.black_player_id)
        .maybeSingle();

      setWhitePlayer(whiteData);
      setBlackPlayer(blackData);
      setLoading(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load game');
      setLoading(false);
    }
  };

  const handleMove = async (from: string, to: string): Promise<boolean> => {
    if (!game || !user) return false;

    const isWhiteTurn = moves.length % 2 === 0;
    const isPlayerWhite = user.id === game.white_player_id;

    if ((isWhiteTurn && !isPlayerWhite) || (!isWhiteTurn && isPlayerWhite)) {
      setError('Not your turn');
      return false;
    }

    try {
      const moveNumber = moves.length + 1;
      const { error: moveError } = await supabase.from('game_moves').insert({
        game_id: gameId,
        move_number: moveNumber,
        from_square: from,
        to_square: to,
        san: `${from}${to}`,
      });

      if (moveError) throw moveError;

      await fetchGame();
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to make move');
      return false;
    }
  };

  const copyGameLink = async () => {
    const link = `${window.location.origin}/game/${gameId}`;
    await navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <div className="text-white text-xl">Loading game...</div>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <div className="text-white text-center">
          <p className="text-xl mb-4">{error}</p>
          <button
            onClick={() => navigate('/dashboard')}
            className="px-6 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const playerColor = user?.id === game.white_player_id ? 'white' : 'black';
  const isPlayerTurn =
    (playerColor === 'white' && moves.length % 2 === 0) ||
    (playerColor === 'black' && moves.length % 2 === 1);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center gap-2 text-slate-300 hover:text-white mb-6 transition-colors"
        >
          <ChevronLeft size={20} />
          Back to Dashboard
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-slate-800 rounded-lg shadow-2xl p-6 mb-6">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">Chess Game</h2>
                  <p className="text-slate-400">Move {moves.length + 1}</p>
                </div>
                <button
                  onClick={copyGameLink}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg transition-colors"
                >
                  {copied ? <Check size={18} /> : <Copy size={18} />}
                  {copied ? 'Copied' : 'Share'}
                </button>
              </div>

              <div className="flex justify-center">
                <ChessBoard
                  fen={game.fen}
                  onMove={handleMove}
                  playerColor={playerColor}
                  disabled={!isPlayerTurn || game.status !== 'active'}
                />
              </div>

              {error && <div className="mt-4 p-3 bg-red-900 text-red-200 rounded-lg">{error}</div>}

              <div className="mt-4 text-center">
                {game.status !== 'active' && (
                  <div className="text-lg font-bold text-amber-400">
                    Game Over:{' '}
                    {game.status === 'white_win' ? 'White Wins' : game.status === 'black_win' ? 'Black Wins' : 'Draw'}
                  </div>
                )}
                {isPlayerTurn ? (
                  <p className="text-green-400 font-semibold">Your turn!</p>
                ) : (
                  <p className="text-slate-400">Waiting for opponent...</p>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-slate-800 rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold text-white mb-4">Players</h3>
              <div className="space-y-4">
                <div className={`p-4 rounded-lg ${playerColor === 'white' ? 'bg-amber-600 bg-opacity-20 border border-amber-500' : 'bg-slate-700'}`}>
                  <p className="text-slate-300 text-sm">White</p>
                  <p className="text-white font-semibold">{whitePlayer?.username || 'Loading...'}</p>
                </div>
                <div className={`p-4 rounded-lg ${playerColor === 'black' ? 'bg-slate-700 border border-slate-600' : 'bg-slate-700'}`}>
                  <p className="text-slate-300 text-sm">Black</p>
                  <p className="text-white font-semibold">{blackPlayer?.username || 'Loading...'}</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-800 rounded-lg shadow-lg p-6">
              <h3 className="text-xl font-bold text-white mb-4">Move History</h3>
              <div className="space-y-1 max-h-64 overflow-y-auto">
                {moves.length === 0 ? (
                  <p className="text-slate-400 text-sm">No moves yet</p>
                ) : (
                  moves.map((move) => (
                    <div key={move.id} className="flex items-center justify-between p-2 bg-slate-700 rounded text-slate-300 text-sm">
                      <span>Move {move.move_number}</span>
                      <span className="font-mono text-amber-400">
                        {move.from_square} → {move.to_square}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
