import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Game, Profile } from '../types';
import { LogOut, Plus, Users, Trophy } from 'lucide-react';

export function Dashboard() {
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const [games, setGames] = useState<Game[]>([]);
  const [players, setPlayers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewGame, setShowNewGame] = useState(false);
  const [selectedOpponent, setSelectedOpponent] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    fetchData();
  }, [user, navigate]);

  const fetchData = async () => {
    try {
      const { data: gamesData, error: gamesError } = await supabase
        .from('games')
        .select('*')
        .or(`white_player_id.eq.${user?.id},black_player_id.eq.${user?.id}`)
        .order('created_at', { ascending: false })
        .limit(10);

      if (gamesError) throw gamesError;
      setGames(gamesData || []);

      const { data: playersData, error: playersError } = await supabase
        .from('profiles')
        .select('*')
        .neq('user_id', user?.id)
        .order('username');

      if (playersError) throw playersError;
      setPlayers(playersData || []);

      setLoading(false);
    } catch (err) {
      console.error('Failed to fetch data:', err);
      setLoading(false);
    }
  };

  const createNewGame = async () => {
    if (!selectedOpponent || !user) return;

    try {
      const { data, error } = await supabase
        .from('games')
        .insert({
          white_player_id: user.id,
          black_player_id: selectedOpponent,
        })
        .select()
        .single();

      if (error) throw error;
      navigate(`/game/${data.id}`);
    } catch (err) {
      console.error('Failed to create game:', err);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  const activeGames = games.filter((g) => g.status === 'active');
  const completedGames = games.filter((g) => g.status !== 'active');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Chess Arena</h1>
            <p className="text-slate-400">Welcome, {profile?.username}</p>
          </div>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
          >
            <LogOut size={18} />
            Sign Out
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-gradient-to-br from-green-600 to-emerald-700 rounded-lg shadow-lg p-6">
            <p className="text-green-100 text-sm font-semibold mb-1">Wins</p>
            <p className="text-4xl font-bold text-white">{profile?.wins || 0}</p>
          </div>
          <div className="bg-gradient-to-br from-orange-600 to-amber-700 rounded-lg shadow-lg p-6">
            <p className="text-orange-100 text-sm font-semibold mb-1">Draws</p>
            <p className="text-4xl font-bold text-white">{profile?.draws || 0}</p>
          </div>
          <div className="bg-gradient-to-br from-red-600 to-pink-700 rounded-lg shadow-lg p-6">
            <p className="text-red-100 text-sm font-semibold mb-1">Losses</p>
            <p className="text-4xl font-bold text-white">{profile?.losses || 0}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-800 rounded-lg shadow-2xl p-6">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                <Trophy size={24} />
                Active Games ({activeGames.length})
              </h2>

              {activeGames.length === 0 ? (
                <p className="text-slate-400">No active games. Create one to get started!</p>
              ) : (
                <div className="space-y-3">
                  {activeGames.map((game) => (
                    <div
                      key={game.id}
                      onClick={() => navigate(`/game/${game.id}`)}
                      className="p-4 bg-slate-700 hover:bg-slate-600 rounded-lg cursor-pointer transition-colors"
                    >
                      <p className="text-white font-semibold">Game #{game.id.slice(0, 8)}</p>
                      <p className="text-slate-400 text-sm">Move {game.move_count}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-slate-800 rounded-lg shadow-2xl p-6">
              <h2 className="text-2xl font-bold text-white mb-4">Completed Games</h2>

              {completedGames.length === 0 ? (
                <p className="text-slate-400">No completed games yet</p>
              ) : (
                <div className="space-y-3">
                  {completedGames.map((game) => (
                    <div key={game.id} className="p-4 bg-slate-700 rounded-lg">
                      <div className="flex justify-between items-center">
                        <p className="text-white font-semibold">Game #{game.id.slice(0, 8)}</p>
                        <span className={`px-3 py-1 rounded text-sm font-semibold ${
                          game.status === 'white_win' ? 'bg-blue-600 text-white' :
                          game.status === 'black_win' ? 'bg-gray-600 text-white' :
                          'bg-amber-600 text-white'
                        }`}>
                          {game.status === 'white_win' ? 'White Won' :
                           game.status === 'black_win' ? 'Black Won' : 'Draw'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="bg-slate-800 rounded-lg shadow-2xl p-6 h-fit">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <Users size={24} />
              New Game
            </h2>

            {showNewGame ? (
              <div className="space-y-3">
                <div className="max-h-64 overflow-y-auto space-y-2">
                  {players.length === 0 ? (
                    <p className="text-slate-400 text-sm">No other players available</p>
                  ) : (
                    players.map((player) => (
                      <button
                        key={player.id}
                        onClick={() => {
                          setSelectedOpponent(player.user_id);
                          createNewGame();
                        }}
                        className={`w-full p-3 rounded-lg text-left transition-colors ${
                          selectedOpponent === player.user_id
                            ? 'bg-amber-600 text-white'
                            : 'bg-slate-700 text-white hover:bg-slate-600'
                        }`}
                      >
                        <p className="font-semibold">{player.username}</p>
                        <p className="text-sm opacity-75">{player.wins}W {player.losses}L {player.draws}D</p>
                      </button>
                    ))
                  )}
                </div>
                <button
                  onClick={() => setShowNewGame(false)}
                  className="w-full px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowNewGame(true)}
                className="w-full px-4 py-3 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white rounded-lg font-bold flex items-center justify-center gap-2 transition-all"
              >
                <Plus size={20} />
                Start New Game
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
