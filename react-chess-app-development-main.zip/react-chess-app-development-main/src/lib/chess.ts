import { Board, Piece } from '../types';

export class ChessGame {
  private board: Board = [];
  private fen: string = '';
  private moveHistory: string[] = [];

  constructor(fen: string = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1') {
    this.fen = fen;
    this.loadFromFen(fen);
  }

  private loadFromFen(fen: string): void {
    const boardPart = fen.split(' ')[0];
    this.board = [];
    const ranks = boardPart.split('/');

    for (let rank = 0; rank < 8; rank++) {
      this.board[rank] = [];
      let fileIndex = 0;
      for (const char of ranks[rank]) {
        if (/\d/.test(char)) {
          for (let i = 0; i < parseInt(char); i++) {
            this.board[rank][fileIndex] = {
              piece: null,
              isLight: (rank + fileIndex) % 2 === 1,
            };
            fileIndex++;
          }
        } else {
          this.board[rank][fileIndex] = {
            piece: char as Piece,
            isLight: (rank + fileIndex) % 2 === 1,
          };
          fileIndex++;
        }
      }
    }
  }

  getBoard(): Board {
    return this.board;
  }

  getFen(): string {
    return this.fen;
  }

  getSquare(file: number, rank: number): Piece {
    if (file < 0 || file > 7 || rank < 0 || rank > 7) return null;
    return this.board[rank][file].piece;
  }

  isValidMove(fromFile: number, fromRank: number, toFile: number, toRank: number, playerColor: 'white' | 'black'): boolean {
    const piece = this.getSquare(fromFile, fromRank);
    if (!piece) return false;

    const isWhitePiece = piece === piece.toUpperCase();
    if ((playerColor === 'white' && !isWhitePiece) || (playerColor === 'black' && isWhitePiece)) {
      return false;
    }

    const targetSquare = this.getSquare(toFile, toRank);
    if (targetSquare) {
      const targetIsWhite = targetSquare === targetSquare.toUpperCase();
      if (isWhitePiece === targetIsWhite) return false;
    }

    const pieceLower = piece.toLowerCase();
    switch (pieceLower) {
      case 'p':
        return this.isValidPawnMove(fromFile, fromRank, toFile, toRank, isWhitePiece);
      case 'n':
        return this.isValidKnightMove(fromFile, fromRank, toFile, toRank);
      case 'b':
        return this.isValidBishopMove(fromFile, fromRank, toFile, toRank);
      case 'r':
        return this.isValidRookMove(fromFile, fromRank, toFile, toRank);
      case 'q':
        return this.isValidQueenMove(fromFile, fromRank, toFile, toRank);
      case 'k':
        return this.isValidKingMove(fromFile, fromRank, toFile, toRank);
      default:
        return false;
    }
  }

  private isValidPawnMove(fromFile: number, fromRank: number, toFile: number, toRank: number, isWhite: boolean): boolean {
    const direction = isWhite ? -1 : 1;
    const startRank = isWhite ? 6 : 1;

    if (fromFile === toFile) {
      if (toRank === fromRank + direction && !this.getSquare(toFile, toRank)) {
        return true;
      }
      if (fromRank === startRank && toRank === fromRank + 2 * direction && !this.getSquare(toFile, fromRank + direction) && !this.getSquare(toFile, toRank)) {
        return true;
      }
    }

    if (Math.abs(fromFile - toFile) === 1 && toRank === fromRank + direction) {
      return !!this.getSquare(toFile, toRank);
    }

    return false;
  }

  private isValidKnightMove(fromFile: number, fromRank: number, toFile: number, toRank: number): boolean {
    const fileDiff = Math.abs(fromFile - toFile);
    const rankDiff = Math.abs(fromRank - toRank);
    return (fileDiff === 2 && rankDiff === 1) || (fileDiff === 1 && rankDiff === 2);
  }

  private isValidBishopMove(fromFile: number, fromRank: number, toFile: number, toRank: number): boolean {
    const fileDiff = Math.abs(fromFile - toFile);
    const rankDiff = Math.abs(fromRank - toRank);

    if (fileDiff !== rankDiff) return false;

    const fileStep = toFile > fromFile ? 1 : -1;
    const rankStep = toRank > fromRank ? 1 : -1;

    let file = fromFile + fileStep;
    let rank = fromRank + rankStep;

    while (file !== toFile) {
      if (this.getSquare(file, rank)) return false;
      file += fileStep;
      rank += rankStep;
    }

    return true;
  }

  private isValidRookMove(fromFile: number, fromRank: number, toFile: number, toRank: number): boolean {
    if (fromFile !== toFile && fromRank !== toRank) return false;

    if (fromFile === toFile) {
      const step = toRank > fromRank ? 1 : -1;
      for (let rank = fromRank + step; rank !== toRank; rank += step) {
        if (this.getSquare(fromFile, rank)) return false;
      }
    } else {
      const step = toFile > fromFile ? 1 : -1;
      for (let file = fromFile + step; file !== toFile; file += step) {
        if (this.getSquare(file, fromRank)) return false;
      }
    }

    return true;
  }

  private isValidQueenMove(fromFile: number, fromRank: number, toFile: number, toRank: number): boolean {
    return this.isValidRookMove(fromFile, fromRank, toFile, toRank) || this.isValidBishopMove(fromFile, fromRank, toFile, toRank);
  }

  private isValidKingMove(fromFile: number, fromRank: number, toFile: number, toRank: number): boolean {
    return Math.abs(fromFile - toFile) <= 1 && Math.abs(fromRank - toRank) <= 1 && (fromFile !== toFile || fromRank !== toRank);
  }

  movePiece(fromFile: number, fromRank: number, toFile: number, toRank: number): boolean {
    const piece = this.getSquare(fromFile, fromRank);
    if (!piece) return false;

    this.board[toRank][toFile].piece = piece;
    this.board[fromRank][fromFile].piece = null;

    const fromSquare = String.fromCharCode(97 + fromFile) + (8 - fromRank);
    const toSquare = String.fromCharCode(97 + toFile) + (8 - toRank);
    this.moveHistory.push(`${fromSquare}${toSquare}`);

    this.updateFen();
    return true;
  }

  private updateFen(): void {
    let fen = '';
    for (let rank = 0; rank < 8; rank++) {
      let emptyCount = 0;
      for (let file = 0; file < 8; file++) {
        const piece = this.board[rank][file].piece;
        if (piece) {
          if (emptyCount) {
            fen += emptyCount;
            emptyCount = 0;
          }
          fen += piece;
        } else {
          emptyCount++;
        }
      }
      if (emptyCount) fen += emptyCount;
      if (rank < 7) fen += '/';
    }

    this.fen = fen + ' w KQkq - 0 ' + Math.floor(this.moveHistory.length / 2 + 1);
  }

  getMoveHistory(): string[] {
    return this.moveHistory;
  }

  squareToCoords(square: string): { file: number; rank: number } | null {
    if (square.length !== 2) return null;
    const file = square.charCodeAt(0) - 97;
    const rank = 8 - parseInt(square[1]);
    if (file < 0 || file > 7 || rank < 0 || rank > 7) return null;
    return { file, rank };
  }

  coordsToSquare(file: number, rank: number): string {
    return String.fromCharCode(97 + file) + (8 - rank);
  }
}
