export interface Profile {
  id: string;
  user_id: string;
  username: string;
  wins: number;
  losses: number;
  draws: number;
  created_at: string;
}

export interface Game {
  id: string;
  white_player_id: string;
  black_player_id: string;
  status: 'active' | 'white_win' | 'black_win' | 'draw';
  fen: string;
  move_count: number;
  created_at: string;
  updated_at: string;
}

export interface GameMove {
  id: string;
  game_id: string;
  move_number: number;
  from_square: string;
  to_square: string;
  promotion: string | null;
  san: string;
  created_at: string;
}

export interface AuthUser {
  id: string;
  email: string;
}

export type Piece = 'K' | 'Q' | 'R' | 'B' | 'N' | 'P' | 'k' | 'q' | 'r' | 'b' | 'n' | 'p' | null;
export type Square = { piece: Piece; isLight: boolean };
export type Board = Square[][];
