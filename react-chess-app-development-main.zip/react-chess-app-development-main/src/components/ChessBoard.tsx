import React, { useState, useEffect } from 'react';
import { ChessGame } from '../lib/chess';
import { Piece } from '../types';

interface ChessBoardProps {
  fen: string;
  onMove: (from: string, to: string) => Promise<boolean>;
  playerColor: 'white' | 'black';
  disabled?: boolean;
}

export function ChessBoard({ fen, onMove, playerColor, disabled = false }: ChessBoardProps) {
  const [game, setGame] = useState<ChessGame>(new ChessGame(fen));
  const [selectedSquare, setSelectedSquare] = useState<{ file: number; rank: number } | null>(null);
  const [validMoves, setValidMoves] = useState<Set<string>>(new Set());
  const [moving, setMoving] = useState(false);

  useEffect(() => {
    setGame(new ChessGame(fen));
  }, [fen]);

  const getPieceUnicode = (piece: Piece): string => {
    const pieces: Record<string, string> = {
      K: '♔',
      Q: '♕',
      R: '♖',
      B: '♗',
      N: '♘',
      P: '♙',
      k: '♚',
      q: '♛',
      r: '♜',
      b: '♝',
      n: '♞',
      p: '♟',
    };
    return pieces[piece as string] || '';
  };

  const handleSquareClick = async (file: number, rank: number) => {
    if (disabled || moving) return;

    if (selectedSquare) {
      const square = game.coordsToSquare(file, rank);
      const fromSquare = game.coordsToSquare(selectedSquare.file, selectedSquare.rank);

      if (validMoves.has(square)) {
        setMoving(true);
        const success = await onMove(fromSquare, square);
        setMoving(false);

        if (success) {
          setSelectedSquare(null);
          setValidMoves(new Set());
        }
      } else {
        const piece = game.getSquare(file, rank);
        if (piece) {
          const isWhitePiece = piece === piece.toUpperCase();
          if ((playerColor === 'white' && isWhitePiece) || (playerColor === 'black' && !isWhitePiece)) {
            setSelectedSquare({ file, rank });
            updateValidMoves(file, rank);
          }
        } else {
          setSelectedSquare(null);
          setValidMoves(new Set());
        }
      }
    } else {
      const piece = game.getSquare(file, rank);
      if (piece) {
        const isWhitePiece = piece === piece.toUpperCase();
        if ((playerColor === 'white' && isWhitePiece) || (playerColor === 'black' && !isWhitePiece)) {
          setSelectedSquare({ file, rank });
          updateValidMoves(file, rank);
        }
      }
    }
  };

  const updateValidMoves = (file: number, rank: number) => {
    const moves = new Set<string>();
    for (let toFile = 0; toFile < 8; toFile++) {
      for (let toRank = 0; toRank < 8; toRank++) {
        if (game.isValidMove(file, rank, toFile, toRank, playerColor)) {
          moves.add(game.coordsToSquare(toFile, toRank));
        }
      }
    }
    setValidMoves(moves);
  };

  const board = game.getBoard();
  const displayBoard = playerColor === 'black' ? [...board].reverse() : board;

  return (
    <div className="inline-block border-4 border-slate-800 shadow-2xl">
      {displayBoard.map((row, rowIndex) => {
        const actualRank = playerColor === 'black' ? 7 - rowIndex : rowIndex;
        return (
          <div key={rowIndex} className="flex">
            {row.map((square, colIndex) => {
              const actualFile = playerColor === 'black' ? 7 - colIndex : colIndex;
              const squareNotation = `${String.fromCharCode(97 + actualFile)}${8 - actualRank}`;
              const isSelected = selectedSquare?.file === actualFile && selectedSquare?.rank === actualRank;
              const isValidMove = validMoves.has(squareNotation);

              return (
                <div
                  key={`${rowIndex}-${colIndex}`}
                  onClick={() => handleSquareClick(actualFile, actualRank)}
                  className={`w-16 h-16 flex items-center justify-center text-5xl font-bold cursor-pointer transition-all ${
                    square.isLight ? 'bg-amber-100' : 'bg-amber-700'
                  } ${isSelected ? 'ring-4 ring-green-400' : ''} ${isValidMove ? 'ring-inset ring-4 ring-blue-400' : ''} ${
                    disabled || moving ? 'opacity-75 cursor-not-allowed' : ''
                  }`}
                >
                  {square.piece && getPieceUnicode(square.piece)}
                  {isValidMove && !square.piece && <div className="w-3 h-3 bg-blue-400 rounded-full"></div>}
                  {isValidMove && square.piece && (
                    <div className="absolute w-16 h-16 border-4 border-blue-400 rounded-lg pointer-events-none"></div>
                  )}
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}
